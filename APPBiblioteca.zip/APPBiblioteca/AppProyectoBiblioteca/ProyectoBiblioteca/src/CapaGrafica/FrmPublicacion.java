package CapaGrafica;

import CapaPersistencia.PublicacionBD;

import java.awt.Color;
import java.awt.Dimension;

import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;

import java.awt.event.WindowEvent;

import java.awt.image.ColorModel;

import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;

import capaLogica.Publicacion;

public class FrmPublicacion extends JFrame {
    private JToolBar jTlbAcciones = new JToolBar();
    private JButton jBtnSalir = new JButton();
    private JButton jBtnAgregar = new JButton();
    private ImageIcon imgAgregar= new ImageIcon(FrmAlquiler.class.getResource("nuevo.png"));  
    private ImageIcon imgModificar = new ImageIcon(FrmAlquiler.class.getResource("modificar.png"));
    private ImageIcon imgEliminar = new ImageIcon(FrmAlquiler.class.getResource("eliminar.png"));
    private ImageIcon imgConsultar = new ImageIcon(FrmAlquiler.class.getResource("consultar.png"));
    private ImageIcon imgSalir = new ImageIcon(FrmAlquiler.class.getResource("salir.png"));
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTable jTblDeptos = new JTable();
    private DefaultTableModel modeloTabla; //Declara modelo para la tabla
    private static Publicacion miPublicacion= null; //Departamento que se utilizar� para agregar, modificar.

    public FrmPublicacion() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(586, 346));
        this.setTitle("Mantenimiento de Publicaciones");
        this.addWindowListener(new WindowAdapter() {
                public void windowOpened(WindowEvent e) {
                    this_windowOpened(e);
                }
            });
        jTlbAcciones.setBounds(new Rectangle(20, 15, 260, 60));
        jTlbAcciones.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
        jTlbAcciones.setFloatable(false);
        jBtnSalir.setText("Salir");
        jBtnSalir.setIcon(imgSalir);
        jBtnSalir.setHorizontalTextPosition(SwingConstants.CENTER);
        jBtnSalir.setVerticalTextPosition(SwingConstants.BOTTOM);
        jBtnSalir.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        jBtnSalir.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jBtnSalir_actionPerformed(e);
                }
            });

        jBtnAgregar.setText("Agregar");
        jBtnAgregar.setIcon(imgAgregar);
        jBtnAgregar.setHorizontalTextPosition(SwingConstants.CENTER);
        jBtnAgregar.setVerticalTextPosition(SwingConstants.BOTTOM);
        jBtnAgregar.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        jBtnAgregar.setBounds(new Rectangle(2, 2, 51, 55));
        jBtnAgregar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jBtnAgregar_actionPerformed(e);
                }
            });
        jScrollPane1.setBounds(new Rectangle(20, 100, 390, 195));
        jTlbAcciones.add(jBtnAgregar, null);
        jTlbAcciones.add(jBtnSalir, null);
        jScrollPane1.getViewport().add(jTblDeptos, null);
        this.getContentPane().add(jScrollPane1, null);
        this.getContentPane().add(jTlbAcciones, null);
    }
      
    private void this_windowOpened(WindowEvent e) {
        asignaModeloTabla();
        llenaTablaPublicaciones();
        
    }
    private void asignaModeloTabla(){
     String[] arregloTitulos = {"Codigo","Titulo", "Precio"};
     //Construir y asignar el modelo a la tabla
     //Construye el modelo con los encabezados del arregloT�tulos
     // con cero filas
     modeloTabla = new DefaultTableModel(arregloTitulos,0);
     this.jTblDeptos.setModel(modeloTabla);  }

    private void llenaTablaPublicaciones() {
        this.modeloTabla.setRowCount(0);
        ArrayList<Publicacion> lista = null;
        String dat []=  new String[3];
            try{
                lista = Publicacion.listaPublicaciones();
            }catch(Exception ex){
                
            }
            for(Publicacion p : lista){
                dat[0] = p.getCodigo()+"";
                dat[1] =p.getTitulo()+"";
                dat[2]= p.costoTotalDiarioPublicacion()+"";
                this.modeloTabla.addRow(dat);
            }  
        
    }

    

    private void jBtnAgregar_actionPerformed(ActionEvent e) {
        jDlgPublicacion p = new jDlgPublicacion('A');
        p.setModal(true);
        p.setLocationRelativeTo(null);
       p.setVisible(true);
       
       if(miPublicacion != null){
           try{
               Publicacion.AgregarPublicacion(miPublicacion);
           }catch(Exception ex){
               
           }
           llenaTablaPublicaciones();
          
           
           
       }
       
       
       
       
    }
   


    private void jBtnSalir_actionPerformed(ActionEvent e) {
        this.dispose();
    }
    
    public static Publicacion getMiPublicacion() {
        return miPublicacion;
    }
    public static void setMiPublicacion(Publicacion publicacion) {
        miPublicacion = publicacion;
    }

}


