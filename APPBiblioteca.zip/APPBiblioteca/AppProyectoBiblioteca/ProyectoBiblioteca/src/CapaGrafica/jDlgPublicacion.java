package CapaGrafica;


import CapaPersistencia.PublicacionBD;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.WindowAdapter;

import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import capaLogica.Libro;
import capaLogica.Periodico;
import capaLogica.Publicacion;

import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.table.DefaultTableModel;

public class jDlgPublicacion extends JDialog {
  
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JTextField jTxtTitulo = new JTextField();
    private JTextField jTxtPrecioAlq = new JTextField();
    private JButton jBtnAceptar = new JButton();
    private JButton jBtnCancelar = new JButton();
    private String codigoDepto;
    private char tipoMantenimiento;
    private JRadioButton jRdbLibro = new JRadioButton();
    private JRadioButton jRdbPeriodico = new JRadioButton();
    private JTextField jtxtAutor = new JTextField();
    private JComboBox jcmbGenero = new JComboBox();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JTextField jtxtDiaPublicacion = new JTextField();
    private JTextField jtxtMesPublicacion = new JTextField();
    private JTextField jtxtA�oPublicacion = new JTextField();
    private JTextField jtxtCantidadPags = new JTextField();
    private ButtonGroup botones = new ButtonGroup();

    public jDlgPublicacion(char tipoMantenimiento) { //OJO el constructor del JDialog recibe un c�digo de Depto
        this(null, "", false);   //llama al otro constructor 
        this.tipoMantenimiento= tipoMantenimiento;  //A = agregar, M = modificar, C = consu
    }

    public jDlgPublicacion(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setSize(new Dimension(699, 300));
        this.getContentPane().setLayout( null );
        this.setFont(new Font("Tahoma", 1, 12));
        this.addWindowListener(new WindowAdapter() {
                public void windowOpened(WindowEvent e) {
                    this_windowOpened(e);
                }
            });
        jLabel1.setText("Titulo");
        jLabel1.setBounds(new Rectangle(40, 65, 85, 20));
        jLabel1.setFont(new Font("Tahoma", 1, 12));
        jLabel2.setText("Precio Alquiler");
        jLabel2.setBounds(new Rectangle(40, 100, 125, 15));
        jLabel2.setFont(new Font("Tahoma", 1, 12));
        jTxtTitulo.setBounds(new Rectangle(200, 65, 125, 25));
        jTxtPrecioAlq.setBounds(new Rectangle(200, 95, 125, 25));
        jBtnAceptar.setText("Aceptar");
        jBtnAceptar.setBounds(new Rectangle(55, 215, 100, 35));
        jBtnAceptar.setFont(new Font("Tahoma", 0, 14));
        jBtnAceptar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jBtnAceptar_actionPerformed(e);
                }
            });
        jBtnCancelar.setText("Cancelar");
        jBtnCancelar.setBounds(new Rectangle(460, 215, 100, 35));
        jBtnCancelar.setFont(new Font("Tahoma", 0, 14));
        jBtnCancelar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jBtnCancelar_actionPerformed(e);
                }
            });
        jRdbLibro.setText("Libro");
        jRdbLibro.setBounds(new Rectangle(35, 20, 130, 20));
        jRdbLibro.setFont(new Font("Tahoma", 1, 12));
        jRdbLibro.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jRadioButton1_actionPerformed(e);
                }
            });
        jRdbPeriodico.setText("Periodico");
        jRdbPeriodico.setBounds(new Rectangle(200, 20, 130, 20));
        jRdbPeriodico.setFont(new Font("Tahoma", 1, 12));
        jRdbPeriodico.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jRdbPeriodico_actionPerformed(e);
                }
            });
        jtxtAutor.setBounds(new Rectangle(200, 170, 125, 25));
        jcmbGenero.setBounds(new Rectangle(200, 130, 125, 25));
        jLabel3.setText("Genero");
        jLabel3.setBounds(new Rectangle(40, 125, 100, 30));
        jLabel3.setFont(new Font("Tahoma", 1, 12));
        jLabel4.setText("Autor");
        jLabel4.setBounds(new Rectangle(40, 165, 110, 25));
        jLabel4.setFont(new Font("Tahoma", 1, 12));
        jLabel5.setText("Dia Publicacion");
        jLabel5.setBounds(new Rectangle(355, 65, 120, 20));
        jLabel5.setFont(new Font("Tahoma", 1, 11));
        jLabel6.setText("Mes Publicacion");
        jLabel6.setBounds(new Rectangle(345, 95, 120, 20));
        jLabel6.setFont(new Font("Tahoma", 1, 11));
        jLabel7.setText("A�o Publicacion");
        jLabel7.setBounds(new Rectangle(350, 135, 120, 20));
        jLabel7.setFont(new Font("Tahoma", 1, 11));
        jLabel8.setText("Cantidad Paginas");
        jLabel8.setBounds(new Rectangle(345, 170, 120, 20));
        jLabel8.setFont(new Font("Tahoma", 1, 11));
        jtxtDiaPublicacion.setBounds(new Rectangle(445, 60, 125, 25));
        jtxtMesPublicacion.setBounds(new Rectangle(445, 95, 125, 25));
        jtxtA�oPublicacion.setBounds(new Rectangle(445, 130, 125, 25));
        jtxtCantidadPags.setBounds(new Rectangle(445, 165, 125, 25));
        this.getContentPane().add(jtxtCantidadPags, null);
        this.getContentPane().add(jtxtA�oPublicacion, null);
        this.getContentPane().add(jtxtMesPublicacion, null);
        this.getContentPane().add(jtxtDiaPublicacion, null);
        this.getContentPane().add(jLabel8, null);
        this.getContentPane().add(jLabel7, null);
        this.getContentPane().add(jLabel6, null);
        this.getContentPane().add(jLabel5, null);
        this.getContentPane().add(jLabel4, null);
        this.getContentPane().add(jLabel3, null);
        this.getContentPane().add(jcmbGenero, null);
        this.getContentPane().add(jtxtAutor, null);
        this.getContentPane().add(jRdbPeriodico, null);
        this.getContentPane().add(jRdbLibro, null);
        this.getContentPane().add(jBtnCancelar, null);
        this.getContentPane().add(jBtnAceptar, null);
        this.getContentPane().add(jTxtPrecioAlq, null);
        this.getContentPane().add(jTxtTitulo, null);
        this.getContentPane().add(jLabel2, null);
        this.getContentPane().add(jLabel1, null);
    }

    private void jBtnAceptar_actionPerformed(ActionEvent e) {
                                                    
         if(this.jRdbLibro.isSelected()){
             String titulo = this.jTxtTitulo.getText();
             Double precio =  Double.parseDouble(this.jTxtPrecioAlq.getText());
             String gen =  this.jcmbGenero.getSelectedItem().toString();
             String autor = this.jtxtAutor.getText();
       
             Publicacion Libro = new Libro(titulo,precio,gen,autor);
             FrmPublicacion.setMiPublicacion(Libro);
             this.dispose();
       
       
         }else{
             if(this.jRdbPeriodico.isSelected()){
      
                 int diaPublicacion = Integer.parseInt(this.jtxtDiaPublicacion.getText());
                 int mesPublicacion = Integer.parseInt(this.jtxtMesPublicacion.getText());
                 int annoPublicacion= Integer.parseInt(this.jtxtA�oPublicacion.getText());
                 int cantidadPaginas =  Integer.parseInt(this.jtxtCantidadPags.getText());
                 String titulo = this.jTxtTitulo.getText();
                 double precio =  Double.parseDouble(this.jTxtPrecioAlq.getText());
      
      
      
                 Publicacion Periodico = new Periodico(titulo,precio,diaPublicacion,mesPublicacion,annoPublicacion,cantidadPaginas);
                 FrmPublicacion.setMiPublicacion(Periodico);
                this.dispose();
             }
         }
         
         
         
      
    }
    private void llenaCOMBO(){
        this.jcmbGenero.removeAllItems();
        this.jcmbGenero.addItem("Novela");
        this.jcmbGenero.addItem("Religion");
        this.jcmbGenero.addItem("Filosofia");
        this.jcmbGenero.addItem("Cuentos Infantiles");
        this.jcmbGenero.addItem("Motivacionales");
        this.jcmbGenero.setSelectedIndex(0);
    }
   
    private void this_windowOpened(WindowEvent e) {
        llenaCOMBO();
        botones.add(jRdbLibro);
        botones.add(jRdbPeriodico);
        jTxtTitulo.setText("");
        jTxtPrecioAlq.setText("");
       //falta
      switch (tipoMantenimiento){
        case 'A':
              jTxtTitulo.setEditable(true);
              this.setTitle("Nueva Publicacion");  //Pone t�tulo al JDialog
              break;
        }
    }
    
    private void jBtnCancelar_actionPerformed(ActionEvent e) {
        FrmPublicacion.setMiPublicacion(null);
        this.dispose();
    }


    private void jRdbPeriodico_actionPerformed(ActionEvent e) {
        this.jcmbGenero.setEditable(false);
        this.jtxtAutor.setEditable(true);
        this.jcmbGenero.setVisible(false);
        this.jtxtAutor.setVisible(false);
        
        
        this.jtxtA�oPublicacion.setVisible(true);
        this.jtxtCantidadPags.setVisible(true);
        this.jtxtDiaPublicacion.setVisible(true);
        this.jtxtMesPublicacion.setVisible(true);
        
        this.jtxtA�oPublicacion.setEditable(true);
        this.jtxtCantidadPags.setEditable(true);
        this.jtxtDiaPublicacion.setEditable(true);
        this.jtxtMesPublicacion.setEditable(true);
        
        
    }

    private void jRadioButton1_actionPerformed(ActionEvent e) {
        this.jtxtA�oPublicacion.setEditable(false);
        this.jtxtCantidadPags.setEditable(false);
        this.jtxtDiaPublicacion.setEditable(false);
        this.jtxtMesPublicacion.setEditable(false);
        
        this.jcmbGenero.setVisible(true);
        this.jtxtAutor.setVisible(true);
        
        this.jtxtA�oPublicacion.setVisible(false);
        this.jtxtCantidadPags.setVisible(false);
        this.jtxtDiaPublicacion.setVisible(false);
        this.jtxtMesPublicacion.setVisible(false);
        
        
    }
}


