package CapaGrafica;


import CapaPersistencia.PublicacionBD;

import capaLogica.Alquiler;
import capaLogica.Cliente;
import capaLogica.Libro;
import capaLogica.Pago;
import capaLogica.Periodico;
import capaLogica.Publicacion;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;


public class FrmAlquiler extends JFrame {
    private JLabel jlblNumeroAlquiler = new JLabel();
    private JTextField jtxtNumeroAlquiler = new JTextField();
    private JRadioButton jrdbLibros = new JRadioButton();
    private JRadioButton jrdbPeriodicos = new JRadioButton();
    private JComboBox jcboPublicaciones = new JComboBox();
    private JLabel jlblNombre = new JLabel();
    private JTextField jtxtNombre = new JTextField();
    private JTextField jtxtCedula = new JTextField();
    private JLabel jlblCedula = new JLabel();
    private JLabel jlblPublicaciones = new JLabel();
    private JList jlstPublicaciones = new JList();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JButton JbtnAgregar = new JButton();
    private JButton jbtnQuitar = new JButton();
    private JLabel jlblfecha = new JLabel();
    private JTextField jtxtFecha = new JTextField();
    private JButton jbtnAlquilar = new JButton();
    private JButton jbtnNuevoAlquiler = new JButton();
    private JButton jbtnSalir = new JButton();
    private JLabel jlblCostoDias = new JLabel();
    private JLabel jlblCostoAdicional = new JLabel();
    private JLabel jlblTotal = new JLabel();
    private JLabel jlblDiasAlquiler = new JLabel();
    private DefaultListModel listaPublicaciones= new DefaultListModel();
    private Alquiler miAlquiler =  new Alquiler();
    private ButtonGroup grupoClientes= new ButtonGroup();
    private ButtonGroup grupoPublicaciones= new ButtonGroup();
    private Cliente miCliente;
    private Publicacion publi;
    private JScrollPane jScrollPane2 = new JScrollPane();
    private ButtonGroup grupoFormaPago=new ButtonGroup();
    private JTextField jtxtCostoDias = new JTextField();
    private JTextField jtxtCostoAdicional = new JTextField();
    private JTextField jtxtTotal = new JTextField();
    private JSeparator jSeparator2 = new JSeparator();
    private ImageIcon publicaciones= new ImageIcon(FrmAlquiler.class.getResource("publicaciones.jpg"));
    private ImageIcon agregar= new ImageIcon(FrmAlquiler.class.getResource("add.JPG"));
    private ImageIcon quitar= new ImageIcon(FrmAlquiler.class.getResource("uncheck.jpg"));
    private ImageIcon alquilar= new ImageIcon(FrmAlquiler.class.getResource("check.PNG"));
    private ImageIcon nuevo= new ImageIcon(FrmAlquiler.class.getResource("nuevo.PNG"));
    private ImageIcon monedas= new ImageIcon(FrmAlquiler.class.getResource("monedas.JPG"));
    private ImageIcon total= new ImageIcon(FrmAlquiler.class.getResource("total.jpg"));
    private ImageIcon salir= new ImageIcon(FrmAlquiler.class.getResource("salir.jpg"));
    private JSeparator jSeparator1 = new JSeparator();
    private JTextArea jTxaAlquiler = new JTextArea();
    private JLabel jLabel1 = new JLabel();
    private JTextField jTxtComprobante = new JTextField();
    private JSeparator jSeparator3 = new JSeparator();
    private JSeparator jSeparator4 = new JSeparator();
    private JTextField jtxtDiasAlquiler = new JTextField();
    private ArrayList<Publicacion> listaPub = null;
    private JButton jbtnAgregarAlquiler = new JButton();
    private JScrollPane jScrollPane3 = new JScrollPane();
    private JTable jtblListaDeAlquileres = new JTable();
    private DefaultTableModel tablamodelo = new DefaultTableModel();
    private JButton jbtnVerOrden = new JButton();

    public FrmAlquiler() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(880, 694));
        this.setTitle( "Alquiler" );
        this.setBackground(new Color(214, 214, 214));
        this.addWindowListener(new WindowAdapter() {
                    public void windowOpened(WindowEvent e) {
                        this_windowOpened(e);
                    }
                });
        jlblNumeroAlquiler.setText("No Alquiler");
        jlblNumeroAlquiler.setBounds(new Rectangle(20, 50, 65, 20));
        jtxtNumeroAlquiler.setBounds(new Rectangle(90, 50, 80, 20));
        jtxtNumeroAlquiler.setEditable(false);
        jrdbLibros.setText("Libros");
        jrdbLibros.setBounds(new Rectangle(5, 240, 84, 19));
        jrdbLibros.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jrdbLibros_actionPerformed(e);
                }
            });
        jrdbPeriodicos.setText("Peri�dicos");
        jrdbPeriodicos.setBounds(new Rectangle(5, 265, 95, 20));
        jrdbPeriodicos.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jrdbPeriodicos_actionPerformed(e);
                    }
                });
        jcboPublicaciones.setBounds(new Rectangle(5, 295, 285, 20));
        jcboPublicaciones.setEnabled(false);
        
        jlblNombre.setText("Nombre");
        jlblNombre.setBounds(new Rectangle(25, 115, 65, 15));
        jtxtNombre.setBounds(new Rectangle(75, 115, 120, 20));
        jtxtNombre.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jtxtNombre_actionPerformed(e);
                    }
                });
        jtxtCedula.setBounds(new Rectangle(75, 145, 120, 20));
        jlblCedula.setText("C�dula");
        jlblCedula.setBounds(new Rectangle(25, 150, 45, 15));
        jlblPublicaciones.setText("Publicaciones");
        jlblPublicaciones.setBounds(new Rectangle(495, 15, 145, 50));
        jlblPublicaciones.setIcon(publicaciones);


        jScrollPane1.setBounds(new Rectangle(450, 200, 200, 180));
        JbtnAgregar.setText("Agregar");
        JbtnAgregar.setBounds(new Rectangle(305, 230, 125, 35));
        JbtnAgregar.setEnabled(false);
        JbtnAgregar.setIcon(agregar);
        JbtnAgregar.setHorizontalTextPosition(SwingConstants.RIGHT);
        JbtnAgregar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JbtnAgregar_actionPerformed(e);
                    }
                });
        jbtnQuitar.setText("Eliminar");
        jbtnQuitar.setBounds(new Rectangle(315, 275, 110, 35));
        jbtnQuitar.setEnabled(false);
        jbtnQuitar.setIcon(quitar);
        jbtnQuitar.setHorizontalTextPosition(SwingConstants.RIGHT);
        jbtnQuitar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jbtnQuitar_actionPerformed(e);
                    }
                });
        jlblfecha.setText("Fecha");
        jlblfecha.setBounds(new Rectangle(25, 10, 55, 20));
        jtxtFecha.setBounds(new Rectangle(90, 10, 220, 20));
        jtxtFecha.setEditable(false);
        jbtnAlquilar.setText("Alquilar");
        jbtnAlquilar.setBounds(new Rectangle(25, 430, 140, 45));
        jbtnAlquilar.setIcon(alquilar);
        jbtnAlquilar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jbtnAlquilar_actionPerformed(e);
                    }
                });
        jbtnNuevoAlquiler.setText("Nuevo Alquiler");
        jbtnNuevoAlquiler.setBounds(new Rectangle(185, 430, 155, 45));
        jbtnNuevoAlquiler.setIcon(nuevo);
        jbtnNuevoAlquiler.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jbtnNuevoAlquiler_actionPerformed(e);
                    }
                });
        jbtnSalir.setText("Salir");
        jbtnSalir.setBounds(new Rectangle(360, 430, 120, 45));
        jbtnSalir.setIcon(salir);
        jbtnSalir.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jbtnSalir_actionPerformed(e);
                    }
                });
        jlblCostoDias.setText("Costo por dias");
        jlblCostoDias.setBounds(new Rectangle(405, 510, 125, 20));
        jlblCostoDias.setIcon(monedas);
        jlblCostoAdicional.setText("Costo Adicional");
        jlblCostoAdicional.setBounds(new Rectangle(405, 540, 125, 15));
        jlblCostoAdicional.setIcon(monedas);
        jlblTotal.setText("Total");
        jlblTotal.setBounds(new Rectangle(405, 565, 100, 35));
        jlblTotal.setIcon(total);
        jlblDiasAlquiler.setText("Dias de alquiler");
        jlblDiasAlquiler.setBounds(new Rectangle(240, 110, 110, 25));


        jScrollPane2.setBounds(new Rectangle(25, 510, 365, 130));
        jtxtCostoDias.setBounds(new Rectangle(515, 510, 120, 20));
        jtxtCostoDias.setEditable(false);
        jtxtCostoAdicional.setBounds(new Rectangle(515, 540, 120, 20));
        jtxtCostoAdicional.setEditable(false);
        jtxtTotal.setBounds(new Rectangle(515, 570, 120, 20));
        jtxtTotal.setEditable(false);
        jSeparator2.setBounds(new Rectangle(235, 85, 0, 2));
        jSeparator1.setBounds(new Rectangle(0, 395, 895, 15));
        jLabel1.setText("Comprobante No.");
        jLabel1.setBounds(new Rectangle(405, 605, 110, 30));
        jTxtComprobante.setBounds(new Rectangle(515, 605, 120, 20));
        jTxtComprobante.setEditable(false);
        jSeparator3.setBounds(new Rectangle(0, 75, 875, 10));
        jSeparator4.setBounds(new Rectangle(5, 185, 870, 2));
        jtxtDiasAlquiler.setBounds(new Rectangle(335, 105, 55, 30));
        jbtnAgregarAlquiler.setText("Agregar Orden");
        jbtnAgregarAlquiler.setBounds(new Rectangle(505, 425, 155, 45));
        jbtnAgregarAlquiler.setIcon(nuevo);
        jbtnAgregarAlquiler.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    jbtnAgregarAlquiler_actionPerformed(e);
                }
                });
        jScrollPane3.setBounds(new Rectangle(685, 475, 165, 165));
        jbtnVerOrden.setText("Ver orden");
        jbtnVerOrden.setBounds(new Rectangle(700, 435, 120, 25));
        jbtnVerOrden.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jbtnVerOrden_actionPerformed(e);
                }
            });
        jScrollPane3.getViewport().add(jtblListaDeAlquileres, null);
        this.getContentPane().add(jbtnVerOrden, null);
        this.getContentPane().add(jScrollPane3, null);
        this.getContentPane().add(jbtnAgregarAlquiler, null);
        this.getContentPane().add(jtxtDiasAlquiler, null);
        this.getContentPane().add(jSeparator4, null);
        this.getContentPane().add(jSeparator3, null);
        this.getContentPane().add(jTxtComprobante, null);
        this.getContentPane().add(jLabel1, null);
        this.getContentPane().add(jSeparator1, null);
        this.getContentPane().add(jSeparator2, null);
        this.getContentPane().add(jtxtTotal, null);
        this.getContentPane().add(jtxtCostoAdicional, null);
        this.getContentPane().add(jtxtCostoDias, null);
        jScrollPane2.getViewport().add(jTxaAlquiler, null);
        this.getContentPane().add(jScrollPane2, null);
        this.getContentPane().add(jlblDiasAlquiler, null);
        this.getContentPane().add(jlblTotal, null);
        this.getContentPane().add(jlblCostoAdicional, null);
        this.getContentPane().add(jlblCostoDias, null);
        this.getContentPane().add(jbtnSalir, null);
        this.getContentPane().add(jbtnNuevoAlquiler, null);
        this.getContentPane().add(jbtnAlquilar, null);
        this.getContentPane().add(jtxtFecha, null);
        this.getContentPane().add(jlblfecha, null);
        this.getContentPane().add(jbtnQuitar, null);
        this.getContentPane().add(JbtnAgregar, null);
        jScrollPane1.getViewport().add(jlstPublicaciones, null);
        this.getContentPane().add(jScrollPane1, null);
        this.getContentPane().add(jlblPublicaciones, null);
        this.getContentPane().add(jlblCedula, null);
        this.getContentPane().add(jtxtCedula, null);
        this.getContentPane().add(jtxtNombre, null);
        this.getContentPane().add(jlblNombre, null);
        this.getContentPane().add(jcboPublicaciones, null);
        this.getContentPane().add(jrdbPeriodicos, null);
        this.getContentPane().add(jrdbLibros, null);
        this.getContentPane().add(jtxtNumeroAlquiler, null);
        this.getContentPane().add(jlblNumeroAlquiler, null);
        this.jlstPublicaciones.setModel(this.listaPublicaciones);
        this.grupoPublicaciones.add(this.jrdbLibros);
        this.grupoPublicaciones.add(this.jrdbPeriodicos);


    }

    private void this_windowOpened(WindowEvent e) {
        titulos();
        this.grupoClientes.add(this.jrdbLibros);
        this.grupoClientes.add(this.jrdbPeriodicos);
        this.jlstPublicaciones.setModel(listaPublicaciones);
    this.jtxtFecha.setText(miAlquiler.getFecha()+"");
    this.jtxtNumeroAlquiler.setText(miAlquiler.getNumAlquiler()+"");
    }

    
    private void jrdbPeriodicos_actionPerformed(ActionEvent e) {
        habilitarPublicaciones();
    this.jcboPublicaciones.removeAllItems();
    ArrayList<Publicacion> lista = null;
    try{
        lista = Publicacion.listaPublicaciones();
        }catch(Exception ex){ 
        }
   
 
    for(Publicacion pub: lista){
        if(pub instanceof Periodico){
         this.jcboPublicaciones.addItem(pub.getTitulo()+""+pub.getPrecioDiario());
        } 
    }
  this.jcboPublicaciones.setSelectedIndex(0);

    }

    

    private void JbtnAgregar_actionPerformed(ActionEvent e) {
        if(this.jcboPublicaciones.getSelectedIndex() <= -1){
            JOptionPane.showMessageDialog(null,"Se debe de seleccionar una Publicacion");
        }else{
        
            this.listaPublicaciones.addElement(jcboPublicaciones.getSelectedItem() );
            this.jcboPublicaciones.removeItemAt(this.jcboPublicaciones.getSelectedIndex());
        }
     }

    
    private void jbtnAlquilar_actionPerformed(ActionEvent e) {
      
        if(this.jtxtCedula.getText().isEmpty() || this.jtxtNombre.getText().isEmpty() ||this.jtxtDiasAlquiler.getText().isEmpty()){
            miCliente = new Cliente(this.jtxtCedula.getText(),this.jtxtNombre.getText());      
        }
      
         miAlquiler.setMicliente(miCliente);
      
        for(int i=0; i<listaPublicaciones.getSize(); i++){
              Publicacion pub = (Publicacion)listaPublicaciones.getElementAt(i) ;
               miAlquiler.agregarPublicacion(pub);
        }
        
        this.jtxtCostoAdicional.setText(miAlquiler.costoAdicionalPublicaciones()+"");
        
         this.jtxtCostoDias.setText(miAlquiler.costoBasicoPublicaciones()+"" );
        
        this.jtxtTotal.setText(""+ miAlquiler.costoTotal());
        
        Pago mipago = new Pago(Double.parseDouble(this.jtxtTotal.getText() ));
        
        miAlquiler.construyePago(mipago);
        
         this.jTxtComprobante.setText(miAlquiler.getNumAlquiler()+"");
        
         this.jTxaAlquiler.setText(miAlquiler.toString()+"");
         
      
    }


      

    private void habilitarPublicaciones(){
        this.jrdbLibros.setEnabled(true);
        this.jrdbPeriodicos.setEnabled(true);
       this.JbtnAgregar.setEnabled(true);
       this.jbtnQuitar.setEnabled(true);
        this.jcboPublicaciones.setEnabled(true);
    }
    
    


    private void jbtnQuitar_actionPerformed(ActionEvent e) {
        if(this.jlstPublicaciones.getSelectedIndex()==-1 ){
            JOptionPane.showMessageDialog(null,"Se debe de seleccionar un elemento de la lista");
        }else{
            this.listaPublicaciones.removeElementAt(this.jlstPublicaciones.getSelectedIndex());
           Publicacion p = (Publicacion)this.jlstPublicaciones.getSelectedValue();
             this.jcboPublicaciones.addItem(p);
             }
    }

    private void jbtnNuevoAlquiler_actionPerformed(ActionEvent e) {
        this.jtxtCostoDias.setText("");
        this.jtxtCostoAdicional.setText("");
        this.jtxtTotal.setText("");
        this.jtxtNombre.setText("");
        this.jtxtCedula.setText("");
        this.jtxtDiasAlquiler.setText("");
        Alquiler n =new Alquiler(); 
        this.jtxtNumeroAlquiler.setText(n.getContAlquiler()+"");
        this.jcboPublicaciones.setSelectedIndex(-1);
        this.jcboPublicaciones.setEnabled(false);
         this.grupoClientes.clearSelection();
         this.listaPublicaciones.removeAllElements();
        
    //falta
    }
  

    
    private void jbtnSalir_actionPerformed(ActionEvent e) {
      
      this.dispose();
    }
    
    private void jtxtNombre_actionPerformed(ActionEvent e) {
         this.jtxtCedula.requestFocus();
    }


    private void jrdbLibros_actionPerformed(ActionEvent e) {
        habilitarPublicaciones();
    
   ArrayList<Publicacion> lista = null;
   try{
       lista = Publicacion.listaPublicaciones();
   }catch(Exception ex){
       
   }
    this.jcboPublicaciones.removeAllItems();
    for(Publicacion pub : lista ){
        if(pub instanceof Libro){
            this.jcboPublicaciones.addItem(pub.getTitulo()+""+pub.getPrecioDiario());
        }
    }
    this.jcboPublicaciones.setSelectedIndex(0);
   
    }
    private void titulos(){
        String ti[] ={"Lista de Alquileres"};
        this.tablamodelo = new DefaultTableModel(ti,0);
        this.jtblListaDeAlquileres.setModel(tablamodelo);
        this.jtblListaDeAlquileres.setRowSelectionAllowed(true);
    }

    private void llenarOrdenT(){
        String []dat = new String [1];
        dat[0]= miAlquiler+" ";
    }
    
    

    private void jbtnAgregarAlquiler_actionPerformed(ActionEvent e) {
        if(miAlquiler != null){
            try{
                Alquiler.AgregarAlquiler(miAlquiler);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,"Error al grabar la orden"+ "\n"+ ex.toString()+ "\n"+ex.getMessage());
            }
            llenarOrdenT();
        }
    }

    private void jbtnVerOrden_actionPerformed(ActionEvent e) {
        String hil = "";
        if(jtblListaDeAlquileres.getSelectedRow() >= 0){
            hil += this.jtblListaDeAlquileres.getValueAt(jtblListaDeAlquileres.getSelectedRow(),0).toString();
        }
        JOptionPane.showMessageDialog(null,hil.toString());
    }
}
