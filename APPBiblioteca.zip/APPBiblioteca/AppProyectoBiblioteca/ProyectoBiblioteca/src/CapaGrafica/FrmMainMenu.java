package CapaGrafica;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.SwingConstants;

public class FrmMainMenu extends JFrame {
    private JMenuBar menuBar = new JMenuBar();
    private JMenu menuFile = new JMenu();
    private JMenuItem menuFileExit = new JMenuItem();
    private JMenu jMenu1 = new JMenu();
    private JMenuItem jMenuItem1 = new JMenuItem();
    private ImageIcon biblioteca= new ImageIcon(FrmAlquiler.class.getResource("imagenPrincipal.PNG"));
    private JLabel jLabel2 = new JLabel();
    private JMenu jMenu2 = new JMenu();
    private JMenuItem jMenuItem2 = new JMenuItem();


    public FrmMainMenu() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setJMenuBar( menuBar );
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(668, 473));
        this.setTitle("Sistema de Biblioteca");
        menuFile.setText("Archivo");
        menuFileExit.setText( "Exit" );
        menuFileExit.addActionListener( new ActionListener() { public void actionPerformed( ActionEvent ae ) { fileExit_ActionPerformed( ae ); } } );
        jMenu1.setText("Sistema");

        jMenuItem1.setText("Alquilar Publicaciones");
        jMenuItem1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jMenuItem1_actionPerformed(e);
                    }
                });
        menuFile.add( menuFileExit );
        menuBar.add( menuFile );
        jMenu1.add(jMenuItem1);
        menuBar.add(jMenu1);
        jMenu2.add(jMenuItem2);
        menuBar.add(jMenu2);
        this.getContentPane().add(jLabel2, null);

        jLabel2.setText("Bienvenido");
        jLabel2.setBounds(new Rectangle(155, 75, 110, 20));
        jLabel2.setFont(new Font("Californian FB", 3, 20));
        jLabel2.setForeground(Color.white);
        jMenu2.setText("Mantenimiento");
        jMenuItem2.setText("Publicaciones");
        jMenuItem2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jMenuItem2_actionPerformed(e);
                }
            });


    }

    void fileExit_ActionPerformed(ActionEvent e) {
        System.exit(0);
    }


    private void jMenuItem1_actionPerformed(ActionEvent e) {
        FrmAlquiler oFrmAlquiler= new FrmAlquiler();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = oFrmAlquiler.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        oFrmAlquiler.setLocation( ( screenSize.width - frameSize.width ) / 2, ( screenSize.height - frameSize.height ) / 2 );
        
        
        oFrmAlquiler.setVisible(true);
    }


    private void jMenuItem2_actionPerformed(ActionEvent e) {
        FrmPublicacion oFrmPublicac= new FrmPublicacion();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = oFrmPublicac.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        oFrmPublicac.setLocation( ( screenSize.width - frameSize.width ) / 2, ( screenSize.height - frameSize.height ) / 2 );
        
        
        oFrmPublicac.setVisible(true);
    }
}
