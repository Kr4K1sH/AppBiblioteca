package capaLogica;

import java.io.Serializable;

public class Libro extends Publicacion implements Serializable {
    private String genero;
    private String autor;
   
    public Libro(String titulo,double precioDiario,String genero,String autor){
        super(titulo,precioDiario);
        this.genero = genero;
        this.autor = autor;
    }
    public  double precioAdicional(){
        double precio=0;
        if(genero.equalsIgnoreCase("Novela")){
            precio= 25;
        }else{
            if(genero.equalsIgnoreCase("Religion")||genero.equalsIgnoreCase("Filosofia")||
               genero.equalsIgnoreCase("Cuentos infantiles")){
                   precio = 10 ;
               }
        }
        return precio;
    }
    public String info(){
        return "Genero: "+genero+
               "\nAutor: "+autor+
               "\nTitulo: "+super.getTitulo()+
               "\nPrecio: "+super.getPrecioDiario();
    }
    
    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getGenero() {
        return genero;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getAutor() {
        return autor;
    }
}
