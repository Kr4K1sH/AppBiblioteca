package capaLogica;


import CapaPersistencia.PublicacionBD;

import java.io.Serializable;

import java.util.ArrayList;


public abstract class Publicacion implements Serializable{
    private static int contPublic = 1;
    private int codigo;
    private String titulo;
    private double PrecioDiario;
    
    
    public Publicacion(String titulo, double precioDiario){
        this.titulo =  titulo;
        this.PrecioDiario = precioDiario;
            this.codigo =contPublic++;
    }
    public abstract double precioAdicional();
    
    //falta
   
    public double costoTotalDiarioPublicacion(){ //Costo de la publicasi�n por cada d�a de alquiler
          double subtotal=0;
           subtotal = this.precioAdicional()+this.PrecioDiario;
          return subtotal;
    }
    
    public String info(){
        
           return  "C�digo: "+this.codigo+"\nPrecio Diario: "+this.PrecioDiario +
               "\nPrecio adicional :" + this.precioAdicional()+ 
                   "\nPrecio total diario: " + this.costoTotalDiarioPublicacion();
               
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getTitulo() {
        return titulo;
    }
    public void setPrecioDiario(double precioDiario) {
        this.PrecioDiario = precioDiario;
    }
    public double getPrecioDiario() {
        return PrecioDiario;
    }
    public static ArrayList listaPublicaciones()throws Exception{
        ArrayList lis = PublicacionBD.getInstance().listaPublicacions();
        return lis;
    }
    public static void AgregarPublicacion(Publicacion p) throws Exception{
        PublicacionBD.getInstance().agregarPublicacion(p);
    }
   
}
