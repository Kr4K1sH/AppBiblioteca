package capaLogica;

import CapaPersistencia.AlquilerBD;
import CapaPersistencia.PublicacionBD;

import java.text.DecimalFormat;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

public class Alquiler {
    /**
     * @aggregation composite
     */
    private Pago mipago;
   private ArrayList<Publicacion> list = null;
   private Cliente micliente;
   private int contAlquiler=0;
   private int diasAlquiler;
   private Date fecha;
   private int numAlquiler;
    
    public Alquiler() {
       this.mipago= null;
       this.list = new ArrayList<Publicacion>();
        this.micliente = null;
        this.diasAlquiler = contAlquiler++;
        this.fecha = new Date();
        this.numAlquiler = contAlquiler++;
    }
    
    public double costoBasicoPublicaciones(){
        double total=0;
        for(Publicacion p: list){
            total += p.getPrecioDiario();
        }
        return total;
    }
    public double costoAdicionalPublicaciones(){
        double adicional=0;
        for(Publicacion p : list){
            if(p instanceof Libro){
            adicional+=p.precioAdicional()*this.diasAlquiler;
            }else{
                adicional += p.precioAdicional();
            }
            }
        return adicional;
    }
    
    public double costoTotal(){
        double total=0;
        total =this.costoBasicoPublicaciones()+this.costoAdicionalPublicaciones();
        return total;
        }
   
  public void construyePago(Pago mipago){
      mipago = new Pago(this.costoTotal());
    }
    public void agregarPublicacion(Publicacion miPublicacion){
       this.list.add(miPublicacion);
    }
    
    public String toString(){
        DecimalFormat formato= new DecimalFormat("#,###.##");
        String hilera="";
        hilera += "Cliente: "+this.micliente.getNombre()+
            "\nDias de Alquiler: "+this.diasAlquiler+
            "\nNumero Alquiler: "+this.numAlquiler+
            "\nPago :"+this.mipago.getMontoTotalPagar();
        
        for(Publicacion pub: this.list ){
            hilera+="Publicacion: "+pub.getTitulo()+"\n";
        }
        
        
        return hilera;
    }


    public void setMipago(Pago mipago) {
        this.mipago = mipago;
    }

    public Pago getMipago() {
        return mipago;
    }

    public void setList(ArrayList<Publicacion> list) {
        this.list = list;
    }

    public ArrayList<Publicacion> getList() {
        return list;
    }

    public void setMicliente(Cliente micliente) {
        this.micliente = micliente;
    }

    public Cliente getMicliente() {
        return micliente;
    }

    public void setContAlquiler(int contAlquiler) {
        this.contAlquiler = contAlquiler;
    }

    public int getContAlquiler() {
        return contAlquiler;
    }

    public void setDiasAlquiler(int diasAlquiler) {
        this.diasAlquiler = diasAlquiler;
    }

    public int getDiasAlquiler() {
        return diasAlquiler;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setNumAlquiler(int numAlquiler) {
        this.numAlquiler = numAlquiler;
    }

    public int getNumAlquiler() {
        return numAlquiler;
    }
    public static ArrayList listaAlquiler()throws Exception{
        ArrayList lis = AlquilerBD.getInstance().listaAlquileres();
        return lis;
    }
    public static void AgregarAlquiler(Alquiler a) throws Exception{
        AlquilerBD.getInstance().agregarAlquiler(a);
    }
    
}
