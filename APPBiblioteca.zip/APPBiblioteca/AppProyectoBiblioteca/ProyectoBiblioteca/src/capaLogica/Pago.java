package capaLogica;

public class Pago {
    private static int contComprobantes=0;
    private int numComprobante;
    private double montoTotalPagar;
   
    public Pago(double montoTotalPagar) {
       this.montoTotalPagar=montoTotalPagar;
       this.contComprobantes++;
       this.numComprobante = contComprobantes;
    }
    public String toString(){
        String hilera=
        "No Comprobante: "+this.numComprobante;
        return hilera;
    }
    public void setNumComprobante(int numComprobante) {
        this.numComprobante = numComprobante;
    }

    public int getNumComprobante() {
        return numComprobante;
    }

    public void setMontoTotalPagar(double montoTotalPagar) {
        this.montoTotalPagar = montoTotalPagar;
    }

    public double getMontoTotalPagar() {
        return montoTotalPagar;
    }
    
}
