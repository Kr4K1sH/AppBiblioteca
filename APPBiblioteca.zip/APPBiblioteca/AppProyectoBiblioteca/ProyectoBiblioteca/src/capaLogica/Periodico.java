package capaLogica;

import java.io.Serializable;

import java.util.Date;

public class Periodico extends Publicacion implements Serializable{
    private int diaPublicacion,mesPublicacion,annoPublicacion;
    private int cantidadPaginas;
    
    public Periodico(String titulo,double precioDiario,int diaPublicacion,int mesPublicacion,
                     int annoPublicacion,int cantidadPaginas){
        super(titulo,precioDiario);
        this.diaPublicacion= diaPublicacion;
        this.mesPublicacion = mesPublicacion;
        this.annoPublicacion = annoPublicacion;
        this.cantidadPaginas = cantidadPaginas;
    }
    public  double precioAdicional(){
        double precio = 0;
        precio = this.cantidadPaginas*3;
        return precio;
        }
    
  //falta
 
    public String info(){
        String hilera=""+
          "\nPeri�dico"+
          "\nT�tulo:  "+this.getTitulo() +"   Cantidad de paginas: "+this.cantidadPaginas+"\nFecha de publicaci�n: "+
          this.diaPublicacion+'/'+this.mesPublicacion+'/'+this.annoPublicacion+
          "\n"+super.info();
          return hilera;
    }
        
    


    public void setCantidadPaginas(int cantidadPaginas) {
        this.cantidadPaginas = cantidadPaginas;
    }

    public int getCantidadPaginas() {
        return cantidadPaginas;
    }

    public void setDiaPublicacion(int diaPublicacion) {
        this.diaPublicacion = diaPublicacion;
    }

    public int getDiaPublicacion() {
        return diaPublicacion;
    }

    public void setMesPublicacion(int mesPublicacion) {
        this.mesPublicacion = mesPublicacion;
    }

    public int getMesPublicacion() {
        return mesPublicacion;
    }

    public void setAnnoPublicacion(int annoPublicacion) {
        this.annoPublicacion = annoPublicacion;
    }

    public int getAnnoPublicacion() {
        return annoPublicacion;
    }
}
