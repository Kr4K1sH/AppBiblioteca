package capaLogica;

public class Cliente {
    private String cedula;
    private String nombre;
    
    public Cliente(String cedula,String nombre) {
        this.cedula=cedula;
        this.nombre=nombre;
    }
   
  
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String toString(){
        String hilera=
          "Nombre: " +this.nombre+"   C�dula: "+this.cedula+"   ";
          return hilera;
    }
    
    public String getCedula() {
        return cedula;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    
}
